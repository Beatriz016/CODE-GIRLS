# dynamodb-example-table
Basic script to create a DynamoDB table and load it with a few items

https://docs.aws.amazon.com/pt_br/cli/latest/userguide/getting-started-install.html

1 Baixar AWS CLI
2 Instalar 
3 Criar user Progrmatico
4 Configurar AWS CLI
5 Rodar Script de Automação
